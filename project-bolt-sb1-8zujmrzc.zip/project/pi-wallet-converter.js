const bip39 = require('bip39');
const ed25519HdKey = require('ed25519-hd-key');
const StellarSdk = require('stellar-sdk');

async function convertPassphraseToKeys(mnemonic) {
  if (!bip39.validateMnemonic(mnemonic)) {
    throw new Error('Invalid mnemonic passphrase');
  }

  const seed = await bip39.mnemonicToSeed(mnemonic);
  const derived = ed25519HdKey.derivePath("m/44'/314159'/0'", seed);
  const keypair = StellarSdk.Keypair.fromRawEd25519Seed(derived.key);

  return {
    publicKey: keypair.publicKey(),
    secretKey: keypair.secret()
  };
}

async function main() {
  const mnemonic = process.argv[2];

  if (!mnemonic) {
    console.error('Usage: node pi-wallet-converter.js "<24-word passphrase>"');
    process.exit(1);
  }

  try {
    const keys = await convertPassphraseToKeys(mnemonic);
    console.log('Public Key:', keys.publicKey);
    console.log('Secret Key:', keys.secretKey);
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}

module.exports = { convertPassphraseToKeys };
