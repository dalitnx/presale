const fs = require('fs').promises;
const { convertPassphraseToKeys } = require('./pi-wallet-converter');

async function batchConvert() {
  try {
    console.log('Reading passphrases from fees.txt...');
    const fileContent = await fs.readFile('fees.txt', 'utf-8');
    const passphrases = fileContent.split('\n').filter(line => line.trim());

    console.log(`Found ${passphrases.length} passphrases to convert\n`);

    const publicKeys = [];
    let successCount = 0;
    let errorCount = 0;

    for (let i = 0; i < passphrases.length; i++) {
      const passphrase = passphrases[i].trim();

      if (!passphrase) continue;

      try {
        console.log(`[${i + 1}/${passphrases.length}] Converting...`);
        const keys = await convertPassphraseToKeys(passphrase);
        publicKeys.push(keys.publicKey);
        successCount++;
      } catch (error) {
        console.error(`[${i + 1}/${passphrases.length}] Error: ${error.message}`);
        errorCount++;
      }
    }

    await fs.writeFile('list.txt', publicKeys.join('\n'), 'utf-8');

    console.log('\n=== Conversion Complete ===');
    console.log(`Success: ${successCount}`);
    console.log(`Errors: ${errorCount}`);
    console.log(`Public keys saved to list.txt`);

  } catch (error) {
    if (error.code === 'ENOENT') {
      console.error('Error: fees.txt not found. Please create it with one passphrase per line.');
    } else {
      console.error('Error:', error.message);
    }
    process.exit(1);
  }
}

batchConvert();
