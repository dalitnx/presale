const bip39 = require('bip39');
const { convertPassphraseToKeys } = require('./pi-wallet-converter');

async function test() {
  const testMnemonic = bip39.generateMnemonic(256);

  console.log('Generated test mnemonic (24 words):');
  console.log(testMnemonic);
  console.log('\nWord count:', testMnemonic.split(' ').length);
  console.log('\nConverting to Pi Network keys...\n');

  try {
    const keys = await convertPassphraseToKeys(testMnemonic);
    console.log('Success!');
    console.log('Public Key:', keys.publicKey);
    console.log('Secret Key:', keys.secretKey);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

test();
