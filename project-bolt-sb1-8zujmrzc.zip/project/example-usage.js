const { convertPassphraseToKeys } = require('./pi-wallet-converter');

async function exampleUsage() {
  const mnemonic = 'your 24 word passphrase goes here word1 word2 word3 word4 word5 word6 word7 word8 word9 word10 word11 word12 word13 word14 word15 word16 word17 word18 word19 word20 word21 word22 word23 word24';

  try {
    const keys = await convertPassphraseToKeys(mnemonic);

    console.log('Successfully converted passphrase to Pi Network keys:');
    console.log('Public Key:', keys.publicKey);
    console.log('Secret Key:', keys.secretKey);

    return keys;
  } catch (error) {
    console.error('Failed to convert passphrase:', error.message);
    throw error;
  }
}

exampleUsage();
