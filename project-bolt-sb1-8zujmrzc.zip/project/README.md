# Pi Network Wallet Converter

Convert a 24-word passphrase into Pi Network public and secret keys.

## Installation

Dependencies are already installed. If you need to reinstall:

```bash
npm install
```

## Usage

### Batch Conversion (Multiple Wallets)

Convert multiple passphrases from a file:

1. Create `fees.txt` with one passphrase per line (each line should be a 24-word passphrase)
2. Run the batch converter:

```bash
npm run batch
```

or

```bash
node batch-convert.js
```

All public keys will be saved to `list.txt` (one per line).

### Command Line (Single Wallet)

Run directly from the command line:

```bash
node pi-wallet-converter.js "your 24 word passphrase here..."
```

### As a Module

Import and use in your own scripts:

```javascript
const { convertPassphraseToKeys } = require('./pi-wallet-converter');

async function myScript() {
  const mnemonic = 'your 24 word passphrase...';

  const keys = await convertPassphraseToKeys(mnemonic);

  console.log('Public Key:', keys.publicKey);
  console.log('Secret Key:', keys.secretKey);
}
```

### Example

See `example-usage.js` for a complete example:

```bash
node example-usage.js
```

## API

### `convertPassphraseToKeys(mnemonic)`

Converts a BIP39 mnemonic passphrase to Pi Network keys.

**Parameters:**
- `mnemonic` (string): A valid 24-word BIP39 mnemonic passphrase

**Returns:**
- Promise resolving to an object with:
  - `publicKey` (string): The public key
  - `secretKey` (string): The secret key

**Throws:**
- Error if the mnemonic is invalid

## Technical Details

This script uses the Pi Network derivation path: `m/44'/314159'/0'`

The conversion process:
1. Validates the mnemonic using BIP39
2. Converts mnemonic to seed (64-byte buffer)
3. Derives the key using ED25519 HD Key derivation
4. Creates a Stellar keypair from the derived key

## Security Warning

Never share your secret key or mnemonic passphrase. Store them securely and never commit them to version control.
